<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
		$this->load->model('mdl_manage_admin');
		$this->load->model('mdl_login');
		
	}
	function test(){
		$this->mdl_manage_admin->hapus_admin('55');

	}

	public function index()
	{
		$this->_make_sure_is_admin();
		$adm = $this->_admin_data();
		//code


		//code
		
		$data['nama_admin'] = $adm['nama_admin'];
		$data['jabatan_admin'] = $adm['jabatan_admin'];
		$data['email_admin'] = $adm['email_admin'];
		$data['title'] = "Admin";
		$data['konten'] = $this->load->view('admin/konten/dashboard',$data,true);
		$this->load->view('admin/dashboard', $data);	
	}
	public function create_product(){
		$this->_make_sure_is_admin();
		$adm = $this->_admin_data();
		//code

		//code
		
		$data['nama_admin'] = $adm['nama_admin'];
		$data['jabatan_admin'] = $adm['jabatan_admin'];
		$data['email_admin'] = $adm['email_admin'];
		$data['title'] = "Produk";
		$data['konten'] = $this->load->view('admin/konten/produk',$data,true);
		$this->load->view('admin/dashboard', $data);
	}
	public function manage_product(){
		$this->_make_sure_is_admin();
		$adm = $this->_admin_data();
		//code

		//code
		$data['email_admin'] = $adm['email_admin'];
		$data['nama_admin'] = $adm['nama_admin'];
		$data['jabatan_admin'] = $adm['jabatan_admin'];
		$data['title'] = "Produk";
		$data['konten'] = $this->load->view('admin/konten/produk',$data,true);
		$this->load->view('admin/dashboard', $data);
	}
	
	function manage_admin(){
		$this->_make_sure_is_super_admin();
		$adm = $this->_admin_data();




		$data['email_admin'] = $adm['email_admin'];
		$data['nama_admin'] = $adm['nama_admin'];
		$data['jabatan_admin'] = $adm['jabatan_admin'];
		$data['title'] = "Produk";
		$data['konten'] = $this->load->view('admin/konten/manage_admin',$data,true);
		$this->load->view('admin/dashboard', $data);
	}
	function admin_list(){
		$data = $this->mdl_manage_admin->admin_list();
		echo json_encode($data);
	}
	function get_admin(){
		$id_admin = $this->input->get('id_admin');
		$data = $this->mdl_manage_admin->get_admin_by_kode($id_admin);
		echo json_encode($data);
	}

	function simpan_admin(){
		$this->_make_sure_is_admin();
		$this->form_validation->set_rules('username', 'Username', array('required','is_unique[admin.username]','callback_check_panjang_username' ));
		$this->form_validation->set_rules('password', 'Password', array('required','callback_check_panjang_password' ));
		$this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'required|matches[password]');
		if ($this->form_validation->run() == FALSE){
			$check['check_password'] = $this->session->flashdata('password_check');
				// $check['check_password'] = $this->session->flashdata('password_check');
			$check['check_username'] = $this->session->flashdata('username_check');			
		}else {
			$nama = $this->input->post('nama');
			$username = $this->input->post('username');
			$level = $this->input->post('level');
			$password = $this->bcrypt->hash_password($this->input->post('password'));
			$data = $this->mdl_manage_admin->simpan_admin($nama, $username, $password, $level);
			echo json_encode($data);
		}
	}

	function update_admin(){
		$this->_make_sure_is_admin();

		$id_admin = $this->input->post('id_admin');
		$nama = $this->input->post('nama');
		$username = $this->input->post('username');
		$level = $this->input->post('level');
			// $password = $this->bcrypt->hash_password($this->input->post('password'));
		$data = $this->mdl_manage_admin->update_admin($nama, $username, $level, $id_admin);
		echo json_encode($data);
	}     
	function update_password_admin(){
		$this->_make_sure_is_admin();
		$this->form_validation->set_rules('password', 'Password', array('required','callback_check_panjang_password' ));
		$this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'required|matches[password]');
		if ($this->form_validation->run() == FALSE){
			$check['check_password'] = $this->session->flashdata('password_check');
				// $data['check_password'] = $this->session->flashdata('password_check');
			$check['check_username'] = $this->session->flashdata('username_check');			
		}else {
			$id_admin = $this->input->post('id_admin');
			$password = $this->bcrypt->hash_password($this->input->post('password'));
			$data = $this->mdl_manage_admin->update_admin_password($password, $id_admin);
			echo json_encode($data);
		}     
	}
	function hapus_admin(){
		$this->_make_sure_is_admin();
		$id_admin = $this->input->post('id_admin');
		$data = $this->mdl_manage_admin->hapus_admin($id_admin);
		echo json_encode($data);
	}

	function _make_sure_is_admin(){
		$is_user = $this->session->userdata('status_login');
		if ($is_user == "admin_login") {

		}else {
			$this->session->sess_destroy();
			redirect('login','refresh');
		}
	}
	function _admin_data(){
		$this->_make_sure_is_admin();
		$admin_data = $this->admin_info();
		foreach ($admin_data->result() as $value) {
			$adm['nama_admin'] = $value->nama;
			$adm['level_admin'] = $value->level;
			$adm['foto_admin'] = $value->foto;
			$adm['alamat_admin'] = $value->alamat;
			$adm['nomor_telepon_admin'] = $value->nomor_telepon;
			$adm['email_admin'] = $value->email;
		}
		if ($adm['level_admin'] == 1) {
			$adm['jabatan_admin'] = "Super Admin";
		}else{
			$adm['jabatan_admin'] = "Admin";
		}
		return $adm;
	}
	function admin_info(){
		$this->_make_sure_is_admin();
		$id_admin = $this->session->userdata('id_admin_login');
		if ($id_admin == null) {
			redirect('login','refresh');
		}else{
			$this->db->select('*');
			$this->db->from('admin');
			$this->db->join('contact_admin', 'admin.id = contact_admin.id_admin', 'left');
			$this->db->join('data_admin', 'admin.id = data_admin.id_admin', 'left');
			$this->db->where('admin.id', $id_admin);
			$admin = $this->db->get();
		}
		return $admin;
	}
	function _make_sure_is_super_admin(){
		$id_admin = $this->session->userdata('id_admin_login');
		$admin = $this->db->get_where('admin', array('id'=>$id_admin));
		foreach ($admin->result() as $value) {
			$level = $value->level;
		}
		if (isset($level)) {
			if ($level != "1") {
				$this->session->sess_destroy();
				redirect('login','refresh');
			}
		}else{
			$this->session->sess_destroy();
			redirect('login','refresh');
		}
	}
	function sign_out(){
		$this->session->sess_destroy();
		$url = site_url('login');
		echo "$url";
		redirect("$url",'refresh');
	}
	public function check_panjang_username($str)
	{
		if (strlen($str) >= 5){
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('username_check', '<label class="text-danger"><span><i class="fa fa-times" aria-hidden="true">
				</i>Username minimal 5 karakter</span></label>');
			return FALSE;
		}
	}
	public function check_username()
	{
		if($this->mdl_login->get_username($_POST['username']) || strlen($_POST['username']) <5 ){
			echo '<label class="text-danger"><span><i class="fa fa-times" aria-hidden="true">
			</i> Username telah digunakan atau kurang dari 5 karakter</span></label>';
		}
		else {
			echo '<label class="text-success"><span><i class="fa fa-check-circle-o" aria-hidden="true"></i> Username tersedia</span></label>';
		}
	}
	public function check_password()
	{
		$pass1 = $_POST['password'];
		$pass2 = $_POST['confirm_password'];
		if ($pass1 == $pass2 && strlen($pass1)>=5) {
			$hasil = true;
		}else{
			$hasil = false;
		}
		if($hasil){
			echo '<label class="text-success"><span><i class="fa fa-check-circle-o" aria-hidden="true"></i> Password Sesuai</span></label>';
		}
		else {
			echo '<label class="text-danger"><span><i class="fa fa-times" aria-hidden="true">
			</i>Password tidak sama atau kurang dari 5 karakter</span></label>';
			
		}
	}
	public function check_panjang_password($str)
	{
		if (strlen($str) >= 5){
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('password_check', '<label class="text-danger"><span><i class="fa fa-times" aria-hidden="true">
				</i>Password minimal 5 karakter</span></label>');
			return FALSE;
		}
	}

	function _previledge(){

	}

}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */