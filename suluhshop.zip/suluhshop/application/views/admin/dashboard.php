<?php 
require_once('template/header.php');
require_once('template/navbar.php');
require_once('template/sidebar.php');
echo $konten;
require_once('template/footer.php');

?>